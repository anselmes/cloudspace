#!/bin/bash

set -xe

# TODO: add some openstack-helm components: keystone - mariadb - rabbitmq - memcached - horizon - ceph - radosgw
# optionally: glance - cinder - nova - neutron - octavia - barbican - designate
