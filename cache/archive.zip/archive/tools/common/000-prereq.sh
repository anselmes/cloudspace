#!/bin/bash

set -xe

# TODO: add prerequesites
# - compute env vars
# - add overrides
# - write env vars
# - load env vars
# - install krew if not present and add plugins
