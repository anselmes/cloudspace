#!/bin/bash

set -xe

# TODO: deploy kubernetes
