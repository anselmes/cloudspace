#!/bin/bash

# TODO: check if already present
# if not, add

set -xe
